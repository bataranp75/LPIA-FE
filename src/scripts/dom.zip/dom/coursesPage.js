import { HTTP } from '../fetch/http.js';
import { Fallback } from '../utils/fallback.js';

function escapeHtml(value = '') {
    return String(value)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#39;');
}

function normalizeTags(value) {
    if (Array.isArray(value)) {
        return value
            .flat()
            .map((tag) => String(tag).trim())
            .filter(Boolean);
    }

    if (typeof value === 'string') {
        return value
            .split(',')
            .map((tag) => tag.trim())
            .filter(Boolean);
    }

    return [];
}

function formatPrice(price) {
    const value = Number(price || 0);

    if (!Number.isFinite(value) || value <= 0) {
        return 'GRATIS';
    }

    return `Rp ${value.toLocaleString('id-ID')}`;
}

function levelClass(level) {
    const normalized = String(level || 'Beginner').toLowerCase();

    if (normalized === 'intermediate') {
        return 'bg-amber-50 text-amber-700 ring-1 ring-amber-200';
    }

    if (normalized === 'advanced') {
        return 'bg-rose-50 text-rose-700 ring-1 ring-rose-200';
    }

    return 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200';
}

function deliveryClass(value) {
    const normalized = String(value || 'Online').toLowerCase();

    if (normalized === 'offline') {
        return 'bg-indigo-600 text-white';
    }

    return 'bg-sky-600 text-white';
}

function learningClass(value) {
    const normalized = String(value || 'Regular').toLowerCase();

    if (normalized === 'private') {
        return 'bg-violet-600 text-white';
    }

    return 'bg-slate-900 text-white';
}

function tagChipClass(index) {
    if (index === 0) {
        return 'bg-slate-100 text-slate-700 ring-1 ring-slate-200';
    }

    return 'bg-slate-50 text-slate-500 ring-1 ring-slate-200';
}

function getShortTags(tags = [], limit = 3) {
    return normalizeTags(tags).slice(0, limit);
}

export const CoursesPageDOM = {
    timer: null,

    init() {
        const container = document.getElementById('courses-grid-page');
        if (!container) return;

        this.searchInput = document.getElementById('course-search-input');
        this.categoryFilter = document.getElementById('course-category-filter');
        this.levelFilter = document.getElementById('course-level-filter');
        this.deliveryFilter = document.getElementById('course-delivery-filter');
        this.learningFilter = document.getElementById('course-learning-filter');

        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('search')) this.searchInput.value = urlParams.get('search');

        if (urlParams.has('category')) {
            const cat = urlParams.get('category');
            if (this.categoryFilter.querySelector(`option[value="${cat}"]`)) {
                this.categoryFilter.value = cat;
            }
        }

        if (urlParams.has('level')) {
            const level = urlParams.get('level');
            if (this.levelFilter.querySelector(`option[value="${level}"]`)) {
                this.levelFilter.value = level;
            }
        }

        if (urlParams.has('delivery_type')) {
            const delivery = urlParams.get('delivery_type');
            if (this.deliveryFilter.querySelector(`option[value="${delivery}"]`)) {
                this.deliveryFilter.value = delivery;
            }
        }

        if (urlParams.has('learning_type')) {
            const learning = urlParams.get('learning_type');
            if (this.learningFilter.querySelector(`option[value="${learning}"]`)) {
                this.learningFilter.value = learning;
            }
        }

        this.addEventListeners();
        this.fetchCourses();

        window.retryFetchCoursesList = () => this.fetchCourses();
    },

    addEventListeners() {
        this.searchInput.addEventListener('input', () => {
            clearTimeout(this.timer);
            this.timer = setTimeout(() => {
                this.updateURLAndFetch();
            }, 500);
        });

        this.categoryFilter.addEventListener('change', () => this.updateURLAndFetch());
        this.levelFilter.addEventListener('change', () => this.updateURLAndFetch());
        this.deliveryFilter.addEventListener('change', () => this.updateURLAndFetch());
        this.learningFilter.addEventListener('change', () => this.updateURLAndFetch());
    },

    updateURLAndFetch() {
        const searchVal = this.searchInput.value.trim();
        const catVal = this.categoryFilter.value;
        const levelVal = this.levelFilter.value;
        const deliveryVal = this.deliveryFilter.value;
        const learningVal = this.learningFilter.value;

        const url = new URL(window.location);

        if (searchVal) url.searchParams.set('search', searchVal);
        else url.searchParams.delete('search');

        if (catVal && catVal !== 'all') url.searchParams.set('category', catVal);
        else url.searchParams.delete('category');

        if (levelVal && levelVal !== 'all') url.searchParams.set('level', levelVal);
        else url.searchParams.delete('level');

        if (deliveryVal && deliveryVal !== 'all') url.searchParams.set('delivery_type', deliveryVal);
        else url.searchParams.delete('delivery_type');

        if (learningVal && learningVal !== 'all') url.searchParams.set('learning_type', learningVal);
        else url.searchParams.delete('learning_type');

        window.history.pushState({}, '', url);
        this.fetchCourses();
    },

    async fetchCourses() {
        const container = document.getElementById('courses-grid-page');
        container.innerHTML = Fallback.skeletonCards(8);

        const urlParams = new URLSearchParams(window.location.search);
        const search = urlParams.get('search') || '';
        const category = urlParams.get('category') || 'all';
        const level = urlParams.get('level') || 'all';
        const delivery_type = urlParams.get('delivery_type') || 'all';
        const learning_type = urlParams.get('learning_type') || 'all';

        let apiEndpoint = '/courses';
        const queryParts = [];

        if (search) queryParts.push(`search=${encodeURIComponent(search)}`);
        if (category !== 'all') queryParts.push(`category=${encodeURIComponent(category)}`);
        if (level !== 'all') queryParts.push(`level=${encodeURIComponent(level)}`);
        if (delivery_type !== 'all') queryParts.push(`delivery_type=${encodeURIComponent(delivery_type)}`);
        if (learning_type !== 'all') queryParts.push(`learning_type=${encodeURIComponent(learning_type)}`);

        if (queryParts.length > 0) {
            apiEndpoint += `?${queryParts.join('&')}`;
        }

        try {
            const response = await HTTP.get(apiEndpoint);
            const courses = Array.isArray(response?.data) ? response.data : (response?.data || []);
            this.render(courses);
        } catch (error) {
            container.innerHTML = Fallback.errorState(
                'Gagal memuat daftar kursus.',
                'window.retryFetchCoursesList()'
            );
        }
    },

    render(courses) {
        const container = document.getElementById('courses-grid-page');

        if (!courses || courses.length === 0) {
            container.className = 'grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-4';
            container.innerHTML = `
                <div class="col-span-full rounded-[2rem] border border-dashed border-slate-300 bg-white p-12 text-center shadow-sm">
                    <div class="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-slate-100 text-slate-500">
                        <i class="fas fa-search-minus text-xl"></i>
                    </div>
                    <h3 class="text-lg font-bold text-slate-900">Tidak ada kursus yang sesuai</h3>
                    <p class="mt-2 text-sm text-slate-500">
                        Coba ubah filter kategori, level, metode, atau jenis kelas.
                    </p>
                </div>
            `;
            return;
        }

        container.className = 'grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-4';

        container.innerHTML = courses.map((course) => {
            const tags = getShortTags(course.tags, 3);
            const extraTags = Math.max(normalizeTags(course.tags).length - tags.length, 0);

            const teacherName = course.teacher?.full_name ? escapeHtml(course.teacher.full_name) : '';
            const category = escapeHtml(course.category || 'General');
            const title = escapeHtml(course.title || 'Tanpa Judul');
            const description = escapeHtml(course.description || 'Pelajari materi ini dan tingkatkan keahlianmu sekarang.');
            const deliveryType = escapeHtml(course.delivery_type || 'Online');
            const learningType = escapeHtml(course.learning_type || 'Regular');
            const level = escapeHtml(course.level || 'Beginner');
            const priceLabel = formatPrice(course.price);
            const detailUrl = `/courses/${course.id}`;

            const tagsHtml = tags.map((tag, index) => `
                <span class="inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-semibold ${tagChipClass(index)}">
                    ${escapeHtml(tag)}
                </span>
            `).join('');

            const extraTagHtml = extraTags > 0
                ? `
                    <span class="inline-flex items-center rounded-full bg-slate-50 px-2.5 py-1 text-[11px] font-semibold text-slate-500 ring-1 ring-slate-200">
                        +${extraTags}
                    </span>
                `
                : '';

            return `
                <article class="group flex h-full flex-col overflow-hidden rounded-[1.75rem] border border-slate-200 bg-white shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_18px_50px_rgba(15,23,42,0.10)]">
                    <a href="${detailUrl}" class="flex h-full flex-col">
                        <div class="relative h-44 overflow-hidden bg-slate-100">
                            <img
                                src="${course.thumbnail_url || Fallback.defaultImage}"
                                onerror="${Fallback.imageOnError()}"
                                alt="${title}"
                                class="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                            />

                            <div class="absolute left-3 top-3 flex flex-wrap gap-2">
                                <span class="rounded-full px-3 py-1 text-[10px] font-black uppercase tracking-[0.22em] shadow-sm ${deliveryClass(course.delivery_type)}">
                                    ${deliveryType}
                                </span>
                                <span class="rounded-full px-3 py-1 text-[10px] font-black uppercase tracking-[0.22em] shadow-sm ${learningClass(course.learning_type)}">
                                    ${learningType}
                                </span>
                            </div>

                            <div class="absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full bg-white/90 text-slate-500 shadow-sm backdrop-blur">
                                <i class="fas fa-heart text-sm"></i>
                            </div>
                        </div>

                        <div class="flex flex-1 flex-col p-5">
                            <div class="mb-2 flex items-center justify-between gap-2">
                                <span class="text-[11px] font-black uppercase tracking-[0.28em] text-violet-600">
                                    ${category}
                                </span>
                                <span class="rounded-full bg-slate-50 px-2.5 py-1 text-[11px] font-semibold text-slate-500 ring-1 ring-slate-200">
                                    ${level}
                                </span>
                            </div>

                            <h3 class="line-clamp-2 text-lg font-black leading-snug text-slate-900 transition-colors group-hover:text-blue-600">
                                ${title}
                            </h3>

                            ${teacherName ? `
                                <p class="mt-2 text-xs font-semibold text-slate-400">
                                    Pengajar: ${teacherName}
                                </p>
                            ` : ''}

                            <p class="mt-3 line-clamp-2 text-sm leading-6 text-slate-500">
                                ${description}
                            </p>

                            <div class="mt-4 flex flex-wrap gap-2">
                                ${tagsHtml}
                                ${extraTagHtml}
                            </div>

                            <div class="mt-auto border-t border-slate-100 pt-4">
                                <div class="flex items-center justify-between gap-3">
                                    <span class="text-base font-black text-blue-700">
                                        ${priceLabel}
                                    </span>

                                    <span class="inline-flex items-center gap-2 rounded-full border border-blue-600 px-4 py-2 text-sm font-bold text-blue-600 transition-all duration-300 group-hover:bg-blue-600 group-hover:text-white">
                                        Lihat Detail
                                        <i class="fas fa-arrow-right text-[11px]"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </a>
                </article>
            `;
        }).join('');
    }
};